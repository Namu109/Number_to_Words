from django.apps import AppConfig


class ComplianceConfig(AppConfig):
    name = 'Compliance'

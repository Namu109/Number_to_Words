from django.db import models

# Create your models here.
import logging
import uuid

from django.db import models

from django.conf import settings
from django.db.models.signals import post_save

from django.dispatch import receiver
from django.db import models
# Create your models here.

logger = logging.getLogger(__name__)

class Compliance(models.Model):
    object_id = models.UUIDField(
        unique=True, editable=False, verbose_name='Public identifier')
    compliance_id=models.CharField(
        max_length=255, null=True, unique=True)
    models.Model
    compliance_title = models.CharField(max_length=255, blank=True)
    description = models.TextField(null=True, blank=True)
    compliance_occurance=models.CharField(max_length=255, blank=True)
    assignee = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True, null=True,
        related_name="%(app_label)s_%(class)s_assignee")
    stakeholder = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True, null=True,
        related_name="%(app_label)s_%(class)s_stakeholder")
    due_date = models.DateField(null=True, blank=True)
    compliance_score=models.CharField(max_length=100, blank=True)
    
   
    
    def __str__(self):
        return self.compliance_title

    class Meta:
        db_table = "compliance_compliance"


@receiver(post_save, sender=Compliance)
def compliance_created(sender, instance, update_fields, created, **kwargs):
    if not instance.compliance_id:
        instance_id = instance.id
        compliance_id = 'AC-{0}'.format(str(instance_id).zfill(3))
        instance.compliance_id = compliance_id
        instance.save()

class ComplianceAction(models.Model):
    object_id = models.UUIDField(
        unique=True, editable=False, verbose_name='Public identifier')
    action_id =models.CharField(
        max_length=255, null=True, unique=True)
    compliance=models.ForeignKey(Compliance,blank=True, null=True, on_delete=models.SET_NULL,
                               related_name="%(app_label)s_%(class)s_compliance")
    action_title=models.CharField(max_length=255, blank=True)
    action_type=models.CharField(max_length=255, blank=True)
    action_owner=models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True, null=True,
        related_name="%(app_label)s_%(class)s_action_owner")
    due_date = models.DateField(null=True, blank=True)
    description =models.TextField(null=True, blank=True)
    
    stakeholder = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, blank=True, null=True,
        related_name="%(app_label)s_%(class)s_stakeholder")
   

    def __str__(self):
        return self.action_title

    
    class Meta:
        db_table = "compliance_complianceaction"


@receiver(post_save, sender=ComplianceAction)
def compliance_action_created(sender, instance, update_fields, created, **kwargs):
    if not instance.action_id:
        instance_id = instance.id
        action_id = 'CA-{0}'.format(str(instance_id).zfill(3))
        instance.action_id = action_id
        instance.save()

import logging
import datetime

from django.contrib.auth import get_user_model
from django.db.models import Count, Sum, F, Q
from rest_framework.serializers import (ModelSerializer, SerializerMethodField,
                                        SlugRelatedField, CharField, ReadOnlyField)
from rest_framework.validators import UniqueTogetherValidator

from Compliance.models import Compliance,ComplianceAction
from django.contrib.auth.hashers import check_password
import re
from rest_framework import serializers
from django.db.models import Avg, Max, Min

logger = logging.getLogger(__name__)



class ComplianceSerializer(ModelSerializer):
    class Meta:
        model = Compliance
        fields='__all__'

class ComplianceListSerializer(ModelSerializer):
	compliance_occurance=SerializerMethodField(read_only=True)
	assignee=SerializerMethodField(read_only=True)
	stakeholder=SerializerMethodField(read_only=True)
	number_of_actions = SerializerMethodField('is_action')
	compliance_score=SerializerMethodField(read_only=True)

	def is_action(self, ComplianceListSerializer):
		self.action=ComplianceAction.objects.filter(compliance=ComplianceListSerializer).values('compliance')
		x=len(self.action)
		return len(self.action)


	def get_compliance_occurance(self,compliance):
		try:
			if compliance.compliance_occurance:
				occurence_dict={
				
				"value": compliance.compliance_occurance
				}
				return occurence_dict
			else:
				return None
		except Exception as e:
			logger.exception("Compliance occurence Doesn't exists")

	def get_assignee(self,compliance):
		try:
			if compliance.assignee:
				assignee_dict={
				"id":compliance.assignee.id,
				"value": compliance.assignee.first_name +" "+ compliance.assignee.last_name
				}
				return assignee_dict
			else:
				return None
		except Exception as e:
			logger.exception("Assignee  Does Not exists ")

	def get_stakeholder(self,compliance):
		try:
			if compliance.stakeholder:
				stakeholder_dict={
				"id":compliance.stakeholder.id,
				"value": compliance.stakeholder.first_name +" "+ compliance.stakeholder.last_name
				}
				return stakeholder_dict
			else:
				return None
		except Exception as e:
			logger.exception("Stakeholder  Does Not exists ")

	def get_compliance_score(self,compliance):
		try:
			score_color=None
			if compliance.compliance_score:
				compliance.compliance_score=float(compliance.compliance_score)
				compliance.compliance_score=round(float("{0:.2f}". format(compliance.compliance_score)))
				if compliance.compliance_score>=0 and compliance.compliance_score<=25:
					score_color="#8B0000"
				if compliance.compliance_score>=26 and compliance.compliance_score<=50:
					score_color="#ffa600"
				if compliance.compliance_score>=51 and compliance.compliance_score<=75:
					score_color="#CEFB02"
				if compliance.compliance_score>=76 and compliance.compliance_score<=100:
					score_color="#74BB66"
			score_dict={
			"compliance_score":compliance.compliance_score,
			"color": score_color
			}
			return score_dict
		except Exception as e:
			logger.exception(f"Getting Exception while Fetching Compliance as {e}")
			return None
	class Meta:
		model = Compliance

		fields = ['compliance_id','compliance_title','description','assignee','stakeholder',
        'compliance_occurance','compliance_score','due_date','object_id','number_of_actions']



class ComplianceActionSerializer(ModelSerializer):
    class Meta:
        model = ComplianceAction
        fields='__all__'

from django.urls import include, path

from . import views
from rest_framework import exceptions
from rest_framework.permissions import AllowAny
from rest_framework.renderers import CoreJSONRenderer
from rest_framework.response import Response
from rest_framework.schemas import SchemaGenerator
from rest_framework.views import APIView


urlpatterns = [
    

    # **************** COMPLIANCE ****************

    #Create Compliance
    path('compliance-create/',views.ComplianceCreateView.as_view(),
        
        name="compliance-create-api"),
    
    #Update Compliance
    path('compliance-update/<str:object_id>/',views.ComplianceUpdateView.as_view(),
        
        name="compliance-update-api"),
    #List Compliances
    path('compliance-list/',views.ComplianceAuditListView.as_view(),
        
        name="compliance-list-api"),

    #Delete Compliance
    path('compliance-delete/<str:object_id>/',views.ComplianceDestroyView.as_view(),
        
        name="compliance-delete-api"),

    #View Single Compliance
    path('compliance-view/<str:object_id>/',views.ComplianceDetailView.as_view(),
        
        name="compliance-detail-api"),

    

    # ***************** COMPLIANCE ACTION ********************

    #Create Compliance Action
    path('Action-create/',views.ComplianceActionCreateView.as_view(),
        
        name="Action-create-api"),


    ]
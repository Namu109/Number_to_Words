import datetime

from django.contrib.auth.decorators import login_required

# Create your views here.
import logging
import json
from django.db.models import (Avg, Count, ExpressionWrapper, F, Func, Max, Min,Q, Subquery, Sum)
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator

from django.http import (JsonResponse)
from rest_framework.reverse import reverse

from rest_framework.response import Response
from Compliance.models import *

from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404
# from utils.functions import clean_filter_dict, gen_object_id,prepare_or_query,get_details_for_notification,\
#      get_latest_history_of_an_object, check_for_deletion, check_for_creation_approval, \
#      get_color_by_asset_name,update_query_filters

from .serializers import ComplianceSerializer,ComplianceListSerializer,\
    ComplianceActionSerializer
#     ComplianceActionDetailSeriallizer, \
#     CommentDocSerializer, ComplianceActionListSeriallizer,\
#   
from rest_framework.generics import ListAPIView,CreateAPIView,RetrieveUpdateAPIView,DestroyAPIView,RetrieveAPIView
from django.http import Http404, HttpResponseRedirect, HttpResponse
from rest_framework.views import APIView



logger = logging.getLogger(__name__)
User = get_user_model()

def gen_object_id(model_instance):
    """
    Generate object id
    """
    import uuid
    obj_id = uuid.uuid4()
    count = model_instance.objects.filter(object_id=obj_id).count()
    if count:
        gen_object_id(model_instance)
    else:
        return obj_id




class ComplianceCreateView(CreateAPIView):
    queryset = Compliance.objects.order_by('id').all()
    serializer_class = ComplianceSerializer

    """Create a new Compliance record"""

    def perform_create(self, serializer):
        
        try:
            data={}     
            compliance_ob=serializer.save(object_id=gen_object_id(Compliance))
            data['status'] = "success"
            data['message'] = "Compliance Audit created successfully"
            return data                                      
        except Exception as e:
            logger.exception(f"Something went wrong {e}")
            data['status'] = "failed"
            data['message'] = "Something went wrong"

        return data

        
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = self.perform_create(serializer)
        if data['status'] == 'success':
            return Response(data=data, status=200)
        else:
            return Response(data=data, status=500)


class ComplianceUpdateView(RetrieveUpdateAPIView):
    
    """
    Compliance Edit View
    """
    queryset = Compliance.objects.order_by('id').all()
    serializer_class = ComplianceSerializer

    lookup_field = "object_id"

    def perform_update(self, serializer):
        data = {}
        try:
            
            compliance_ob=serializer.save()
            data['status'] = "success"
            data['message'] = "Compliance Audit updated successfully"

            return data
        except Exception as e:
            logger.exception(f"Something went wrong {e}")
            data['status'] = "failed"
            data['message'] = "Something went wrong"

        return data

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        partial = kwargs.pop('partial', False)
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        data = self.perform_update(serializer)
        if data['status'] == 'success':
            return Response(data=data,status=200)
        else:
            return Response(data=data,status=500)


class ComplianceAuditListView(ListAPIView):
    """
    List of all Compliance
    """
    serializer_class = ComplianceListSerializer

    # overriding the method

    def get_queryset(self, *args, **kwargs):
        try:
            queryset_list = Compliance.objects.order_by('-compliance_id')
        except Compliance.DoesNotExist:
            return queryset_list

        # get the query string
        query = self.request.GET.get("q")
        # get the column number for column based search
        search_column = self.request.GET.get(u'search_column', None)
        # list of tablecolumns
        columns = ['compliance_id','compliance_title', 'compliance_score', 'assignee']

        self.list_of_columns = columns
        # converting tp integer if we got string
        if search_column:
            search_column = int(search_column)

        if query:
            # generating the query
            search_query = get_query_filter(query,columns,Compliance)
            # filtering the search results
            queryset_list = queryset_list.filter(search_query)

        
        return queryset_list


class ComplianceDestroyView(DestroyAPIView):
    """
     Compliance Delete API View
    """
    queryset = Compliance.objects.order_by('id').all()
    serializer_class = ComplianceSerializer

    lookup_field = "object_id"


    def perform_destroy(self, instance):
        data = {}
        try:
            
            self.object_id = self.kwargs.get("object_id")
            compliance_ob=Compliance.objects.get(object_id=self.object_id)
            query = Compliance.objects.get(object_id=self.object_id)
           
            
            
            data['status'] = True
            data['msg'] = "Record Deleted Successfully"
            
            query.delete()
        except Exception as e:
            logger.exception(f"Something went wrong {e}")
            data['status'] = "failed"
            data['message'] = "Something went wrong"
            
        return data

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        data = self.perform_destroy(instance)
        return Response(data=data)


class ComplianceDetailView(RetrieveAPIView):
    """
    Compliance Detail View
    """
    queryset = Compliance.objects.order_by('id').all()
    serializer_class = ComplianceListSerializer

    
    lookup_field = "object_id"

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        data = {"status": True, "data": serializer.data}
        return Response(data)


class ComplianceActionCreateView(CreateAPIView):
    queryset =ComplianceAction.objects.order_by('id').all()
    serializer_class = ComplianceActionSerializer

    """Create a new Compliance Action record"""

    def perform_create(self, serializer):
        
        try:
            data={}     
            action_ob=serializer.save(object_id=gen_object_id(ComplianceAction))
            data['status'] = "success"
            data['message'] = "Compliance Action created successfully"
            return data                                      
        except Exception as e:
            logger.exception(f"Something went wrong {e}")
            data['status'] = "failed"
            data['message'] = "Something went wrong"

        return data

        
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = self.perform_create(serializer)
        if data['status'] == 'success':
            return Response(data=data, status=200)
        else:
            return Response(data=data, status=500)
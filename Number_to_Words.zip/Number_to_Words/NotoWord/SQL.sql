SQL 


#Insert 

INSERT INTO `persons` (`P_id`, `Last_Name`, `First_Name`, `Address`, `City`) 
       VALUES ('5', 'Jam', 'kooky', 'Streets 34', 'Sander');


# And - OR 

SELECT * FROM `persons` WHERE First_Name='jaims' OR Last_Name='kora'


SELECT * FROM `persons` WHERE First_Name='Jaim' AND Last_Name='Jameson'


#Sub Query 

SELECT * FROM `persons` WHERE First_Name='Jaim' AND (Last_Name='Jameson' OR Last_Name='kora')

SELECT * FROM `persons` WHERE First_Name='hariss' AND (Last_Name='Jameson' OR Last_Name='kora')

SELECT * FROM `persons` WHERE First_Name='hariss' OR (Last_Name='Jameson' OR Last_Name='kora')



# Delete 

"DELETE FROM `persons` WHERE `persons`.`P_id` = 7"


#Distinct 

SELECT DISTINCT Address FROM persons


#Order By 


SELECT * FROM persons ORDER by First_Name

SELECT * FROM persons ORDER by Address

SELECT * FROM persons ORDER by Address ASC

SELECT * FROM persons ORDER by P_id DESC


# Update

UPDATE `persons` SET `Last_Name` = 'jaes' WHERE `persons`.`P_id` = 4;


# Current date-time, date , time

SELECT NOW(), CURDATE(), CURTIME()

#AVG

SELECT  AVG(ADVANCE_AMOUNT) as Aveage_Advance_Amount, AVG(ORD_AMOUNT) as Average_Order_Amount from orders

SELECT  cus.cust_Name, ord.ORD_AMOUNT FROM customer cus inner join orders  ord 

on cus.CUST_CODE=ord.CUST_CODE where ord.ORD_AMOUNT>=(SELECT AVG(ord.ORD_AMOUNT) from orders )



#GROUP BY 

SELECT cust_name,CUST_COUNTRY,sum(OPENING_AMT) as Opening_Amount FROM `customer` where OPENING_AMT>4000  GROUP BY CUST_COUNTRY

SELECT cus.cust_name as Customer_name , cus.WORKING_AREA, cus.PAYMENT_AMT, ord.ORD_DATE, ord.ORD_Amount, day.Ord_Amount as Day_Order_Amount FROM daysorder day, `customer` cus inner join orders ord on 
cus.CUST_CODE=ord.CUST_CODE where cus.CUST_CODE=day.CUST_CODE GROUP BY cus.CUST_NAME

SELECT DISTINCT f.Item_Name as ITEM_NAME, f.Item_Unit, com.COMPANY_NAME,com.COMPANY_CITY,Itm.ITEMNAME FROM company com, foods f  INNER 
JOIN  listofitem Itm ON f.ITEM_ID=Itm.ITEM_ID GROUP by f.ITEM_ID

#Having

SELECT cus.cust_name as Customer_name , cus.WORKING_AREA, cus.PAYMENT_AMT, ord.ORD_DATE, 
sum(ord.ORD_Amount), day.Ord_Amount as Day_Order_Amount FROM daysorder day, `customer` cus 
inner join orders ord on  cus.CUST_CODE=ord.CUST_CODE   
where cus.CUST_CODE=day.CUST_CODE  GROUP BY cus.CUST_NAME HAVING sum(ord.ORD_Amount)>10000


SELECT DISTINCT f.Item_Name as ITEM_NAME, f.Item_Unit, com.COMPANY_NAME,com.COMPANY_CITY,Itm.ITEMNAME FROM company com, foods f  INNER 
JOIN  listofitem Itm ON f.ITEM_ID=Itm.ITEM_ID GROUP by f.ITEM_ID HAVING sum(f.COMPANY_ID)>45


from django.apps import AppConfig


class NotowordConfig(AppConfig):
    name = 'NotoWord'

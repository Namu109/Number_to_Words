from django.urls import path, include

from . import views
urlpatterns = [
   
    path('', views.convert,name='converter' ),
    path('IdealWeight',views.IdealWeight,name='IdealWeight'),
]

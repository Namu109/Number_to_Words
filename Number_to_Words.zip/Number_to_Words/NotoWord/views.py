from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
import sys
import os
from gtts import gTTS 
from pygame import mixer
import random
#from rest_framework import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from django.core import serializers
from django.conf import settings
import json




# Create your views here.

# Python program to convert number to words

EMPTY = ""
X = [EMPTY,"One ","Two ","Three ","Four ","Five ","Six ",
		 "Seven ","Eight ","Nine ","Ten ","Eleven ","Twelve ",
		 "Thirteen ","Fourteen ","Fifteen ","Sixteen ",
		 "Seventeen ","Eighteen ","Nineteen"]
Y = [EMPTY, EMPTY,"Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"]	




# Function to convert single digit or two digit number into words
def convertToDigit(n, suffix):    
    	
    if(n == 0):
    	return EMPTY

    if n > 19:
    	return Y[n // 10] + X[n % 10] + suffix
    else:
    	return X[n] + suffix


# Function to convert a given number (max 9-digits) into words
def convert(request):
    if request.method == 'POST':
        number=request.POST.get('number')
        n=int(number)
        # add digits at ten millions & hundred millions place
        result = convertToDigit(((n // 100000) % 100),"Lakh,")
        # add digits at hundred thousands & one millions place
        result += convertToDigit(((n // 1000) % 100),"Thousand")
        # add digits at thousands & tens thousands place
        result += convertToDigit(((n // 100) % 10),"Hundred")
        

        if(n>100 and n%100):
            result += " and "
            result +=convertToDigit((n % 100),"")
        elif(n==0):
            result=EMPTY
        elif(n > 19 and n<100):
            result=Y[n // 10] + X[n % 10]

        elif(n>0 and n<20):
            result=X[n]
        else:
            pass
        language = 'en'
        mytext=result
        r1 = random.randint(1,10000000)
        r2 = random.randint(1,10000000)
        randfile = str(r2)+"music"+str(r1) +".mp3"
        myobj = gTTS(text=mytext, lang=language, slow=False)
        myobj.save(randfile) 
        mixer.init()
        mixer.music.load(randfile)
        mixer.music.play()
        return render(request,'Converter.html',{'no':n,'res':result})
        
    else:

    	result=""
    	return render(request,'Converter.html',{'res':result})





@api_view(["POST"])
def IdealWeight(hightdata):
    try:
        height=json.loads(hightdata.body)
        weight=str(height*10)


        return JsonResponse("Ideal Weight  shoud be "+weight+"kg", safe=False)
    except ValueError as e:
        return Response(e.args[0],status.HTTP_400_BAD_REQUEST)
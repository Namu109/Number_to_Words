This application  is did in python/django 

1. Need internet connection to work the "Text to speech" without that it will  show error

2.Result will take some time depends on internet speed

4.Need two modules named  'gTTS' and 'pygame'  ,install these before run the application